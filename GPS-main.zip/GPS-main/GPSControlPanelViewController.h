#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface GPSControlPanelViewController : UIViewController <MKMapViewDelegate>

@end