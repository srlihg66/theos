#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface WCPulseHelper : NSObject

// 好友检查相关属性
@property (nonatomic, assign) BOOL checkFriendsEnd;
@property (nonatomic, strong) NSArray *notFriends;
@property (nonatomic, strong) NSArray *invalidFriends;
@property (nonatomic, strong) NSArray *validFriends;
@property (nonatomic, strong) NSString *groupURL;
@property (nonatomic, strong) NSString *currentCheckResult;
@property (nonatomic, strong) dispatch_semaphore_t friendCheckSem;

+ (instancetype)shared;

// UI辅助方法
+ (void)showModernToast:(NSString *)message;
+ (UINavigationController *)navigationContrioller;
+ (UIBarButtonItem *)leftNavigationItem;
+ (UIColor *)backgroundColor;
+ (void)Log:(NSString *)message;
+ (CGRect)viewFrame;
+ (UIViewController *)findTopVC;
+ (UIView *)findTopVCView;
+ (NSString *)hexStringFromColor:(UIColor *)color;
+ (void)vibrate;

// 表格管理方法
+ (UITableView *)tableManageWithViewFrame:(CGRect)frame;
+ (NSString *)sectionManage; // 修正：从UITableViewHeaderFooterView *改为NSString *
+ (UITableViewCell *)cellWithTitle:(NSString *)title; // 更新签名
+ (UITableViewCell *)cellWithTitle:(NSString *)title detail:(NSString *)detail; // 新增
+ (UITableViewCell *)cellWithTitle:(NSString *)title switchAction:(void(^)(BOOL))action; // 新增

// 弹窗方法
+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message btnTitle:(NSString *)btnTitle handler:(void(^)(void))handler;
+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message cancelTitle:(NSString *)cancelTitle confirmTitle:(NSString *)confirmTitle handler:(void(^)(BOOL))handler; // 更新签名

// 消息发送方法
+ (void)sendMsg:(NSString *)message toContactUsrName:(NSString *)userName;
+ (void)sendMsg:(NSString *)message toContactUsrName:(NSString *)userName uiMsgType:(NSInteger)msgType;

// 好友和消息相关
+ (NSArray *)allFriends;
+ (void)checkFriends;
+ (NSArray *)commentUsers;
+ (void)commentWith:(NSString *)comment;

// 系统相关
+ (BOOL)vapFileExit;
+ (NSString *)getWechatVersion;

// 公众号相关
+ (void)followMyOfficalAccount;
+ (void)jumpToOfficialAccount;
+ (BOOL)isOfficialAccountFollowed;

// 实例方法
- (void)showSpeedFloatView;
- (void)hideSpeedFloatView;
- (void)action1:(id)sender;
- (void)action2:(id)sender;

@end