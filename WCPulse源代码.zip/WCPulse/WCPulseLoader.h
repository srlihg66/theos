#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface WCPulseLoader : NSObject

// 插件加载器单例
+ (instancetype)sharedLoader;

// 插件生命周期管理
- (void)loadPlugin;
- (void)unloadPlugin;

// Hook管理
- (void)installAllHooks;
- (void)uninstallAllHooks;

// 插件状态
@property (nonatomic, assign, readonly) BOOL isLoaded;
@property (nonatomic, assign, readonly) BOOL hooksInstalled;

@end