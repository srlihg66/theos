#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface WCPulseConfig : NSObject

@property (nonatomic, assign) BOOL pulseEnabled;
@property (nonatomic, strong) UIColor *pulseColor;
@property (nonatomic, assign) CGFloat pulseWidth;

// Instance properties based on IDA analysis
@property (nonatomic, strong) NSString *pluginVer;
@property (nonatomic, assign) BOOL isUIModal;
@property (nonatomic, strong) NSString *myWxid;
@property (nonatomic, assign) BOOL needRedStyle;
@property (nonatomic, assign) BOOL showTopSession;
@property (nonatomic, assign) BOOL isEditing;
@property (nonatomic, assign) BOOL showIconMode;
@property (nonatomic, assign) BOOL showUnreadOnly;
@property (nonatomic, assign) BOOL needOpenEditMode;

+ (instancetype)shared;
+ (instancetype)sharedConfig; // 向后兼容

// 配置文件路径
+ (NSString *)configFilePath;
+ (NSMutableDictionary *)configDictionary;
+ (void)saveConfigDictionary:(NSMutableDictionary *)dictionary;

// 方法转发
+ (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector;
+ (void)forwardInvocation:(NSInvocation *)anInvocation;

// 视频速度手势
+ (BOOL)enableVideoSpeedGesture;
+ (void)setEnableVideoSpeedGesture:(BOOL)enable;

// 时间标签
+ (BOOL)enableTimeLabel;
+ (void)setEnableTimeLabel:(BOOL)enable;
+ (UIColor *)timeLabelColor;
+ (void)setTimeLabelColor:(UIColor *)color;
+ (void)setTimeLabelColorWithHexString:(NSString *)hexString;
+ (CGFloat)timeLabelFontSize;
+ (void)setTimeLabelFontSize:(CGFloat)fontSize;
+ (NSString *)timeLabelDateFormat;
+ (void)setTimeLabelDateFormat:(NSString *)format;
+ (BOOL)enableTimeLabelBold;
+ (void)setEnableTimeLabelBold:(BOOL)enable;
+ (BOOL)hideTimeLabel;
+ (void)setHideTimeLabel:(BOOL)hide;
+ (CGFloat)timeLabelHeight;
+ (void)setTimeLabelHeight:(CGFloat)height;

// 速度文本
+ (NSString *)leftSpeedText;
+ (void)setLeftSpeedText:(NSString *)text;
+ (NSString *)rightSpeedText;
+ (void)setRightSpeedText:(NSString *)text;

// 消息防撤回
+ (BOOL)enableMessageNoRevoke;
+ (void)setEnableMessageNoRevoke:(BOOL)enable;
+ (BOOL)messageNoRevokeNoTip;
+ (void)setMessageNoRevokeNoTip:(BOOL)noTip;
+ (UIColor *)messageNoRevokeColor;
+ (void)setMessageNoRevokeColor:(UIColor *)color;
+ (NSString *)messageNoRevokeDateFormat;
+ (void)setMessageNoRevokeDateFormat:(NSString *)format;
+ (NSString *)messageNoRevokeFormat;
+ (void)setMessageNoRevokeFormat:(NSString *)format;
+ (BOOL)messageNoRevokeBottom;
+ (void)setMessageNoRevokeBottom:(BOOL)bottom;

// 转发功能
+ (BOOL)enableForward;
+ (void)setEnableForward:(BOOL)enable;

// 兼容性提示
+ (BOOL)enableCompatibilityTip;
+ (void)setEnableCompatibilityTip:(BOOL)enable;

// 防删除聊天记录
+ (BOOL)enablePreventDeleteChatRecord;
+ (void)setEnablePreventDeleteChatRecord:(BOOL)enable;

// 弹窗预览
+ (BOOL)enablePopPreview;
+ (void)setEnablePopPreview:(BOOL)enable;

// 转换需求
+ (BOOL)needConvert;
+ (void)setNeedConvert:(BOOL)need;

// 通话确认
+ (BOOL)enableCall2Confirm;
+ (void)setEnableCall2Confirm:(BOOL)enable;

// 自动播放Live Photo
+ (BOOL)enableAutoPlayBaseMsgLivePhoto;
+ (void)setEnableAutoPlayBaseMsgLivePhoto:(BOOL)enable;

// 自动选择原图
+ (BOOL)enableAutoSelectOriginalImage;
+ (void)setEnableAutoSelectOriginalImage:(BOOL)enable;

// 自动选择Live Photo
+ (BOOL)enableAutoSelectLivePhoto;
+ (void)setEnableAutoSelectLivePhoto:(BOOL)enable;

// 群组过滤
+ (NSArray *)groupFilterList;
+ (void)setGroupFilterList:(NSArray *)list;
+ (BOOL)enableGroupFilter;
+ (void)setEnableGroupFilter:(BOOL)enable;
+ (NSDictionary *)groupNameMapping;
+ (void)setGroupNameMapping:(NSDictionary *)mapping;
+ (NSString *)mappedGroupName:(NSString *)originalName;

// 显示设置
+ (BOOL)isShowDonation;
+ (void)setIsShowDonation:(BOOL)show;
+ (BOOL)hideGroupIndicator;
+ (void)setHideGroupIndicator:(BOOL)hide;
+ (BOOL)hideGroupBadge;
+ (void)setHideGroupBadge:(BOOL)hide;
+ (BOOL)hideAllGroupBadge;
+ (void)setHideAllGroupBadge:(BOOL)hide;

// 临时功能配置
+ (BOOL)isTempAddAll;
+ (void)setIsTempAddAll:(BOOL)tempAdd;

// 默认群组索引
+ (NSInteger)defaultGroupIndex;
+ (void)setDefaultGroupIndex:(NSInteger)index;

// 服务号
+ (BOOL)removeServiceAccount;
+ (void)setRemoveServiceAccount:(BOOL)remove;

// 欢迎提示
+ (BOOL)hasShownWelcome;
+ (void)setHasShownWelcome:(BOOL)shown;

// 置顶过滤
+ (BOOL)enableTopFilter;
+ (void)setEnableTopFilter:(BOOL)enable;

// 全局切换群组手势
+ (BOOL)enableGlobalSwitchGroupGesture;
+ (void)setEnableGlobalSwitchGroupGesture:(BOOL)enable;

// 自定义群组列表
+ (NSArray *)customGroupList;
+ (void)setCustomGroupList:(NSArray *)list;

// 震动强度
+ (CGFloat)vibrationStrength;
+ (void)setVibrationStrength:(CGFloat)strength;

// 群组转场动画
+ (BOOL)enableGroupTransitionAnimation;
+ (void)setEnableGroupTransitionAnimation:(BOOL)enable;

// 群组颜色设置 - 浅色模式
+ (UIColor *)groupBackgroundColor;
+ (void)setGroupBackgroundColor:(UIColor *)color;
+ (UIColor *)groupIndicatorColor;
+ (void)setGroupIndicatorColor:(UIColor *)color;
+ (UIColor *)groupFontColor;
+ (void)setGroupFontColor:(UIColor *)color;
+ (UIColor *)groupUnselectedFontColor;
+ (void)setGroupUnselectedFontColor:(UIColor *)color;

// 群组颜色设置 - 深色模式
+ (UIColor *)groupBackgroundColorDark;
+ (void)setGroupBackgroundColorDark:(UIColor *)color;
+ (UIColor *)groupIndicatorColorDark;
+ (void)setGroupIndicatorColorDark:(UIColor *)color;
+ (UIColor *)groupFontColorDark;
+ (void)setGroupFontColorDark:(UIColor *)color;
+ (UIColor *)groupUnselectedFontColorDark;
+ (void)setGroupUnselectedFontColorDark:(UIColor *)color;

// 群组字体大小
+ (CGFloat)groupFontSize;
+ (void)setGroupFontSize:(CGFloat)size;

// 群组指示器样式
+ (NSInteger)groupIndicatorStyle;
+ (void)setGroupIndicatorStyle:(NSInteger)style;

// 隐藏群组背景色
+ (BOOL)hideGroupBackgroundColor;
+ (void)setHideGroupBackgroundColor:(BOOL)hide;

// 版本信息
+ (NSString *)pluginVer;
+ (void)setPluginVer:(NSString *)version;

// 翻译文本背景
+ (BOOL)removeTranslatedTextBg;
+ (void)setRemoveTranslatedTextBg:(BOOL)remove;

// 过滤重复联系人
+ (BOOL)filterDuplicateContacts;
+ (void)setFilterDuplicateContacts:(BOOL)filter;

// 首页圆角
+ (BOOL)enableHomeCorner;
+ (void)setEnableHomeCorner:(BOOL)enable;
+ (CGFloat)homeCornerRadius;
+ (void)setHomeCornerRadius:(CGFloat)radius;
+ (CGFloat)homeCornerHorizontalPadding;
+ (void)setHomeCornerHorizontalPadding:(CGFloat)padding;
+ (CGFloat)homeCornerVerticalPadding;
+ (void)setHomeCornerVerticalPadding:(CGFloat)padding;
+ (UIColor *)homeCornerLightColor;
+ (void)setHomeCornerLightColor:(UIColor *)color;
+ (UIColor *)homeCornerDarkColor;
+ (void)setHomeCornerDarkColor:(UIColor *)color;

// 提示相关
+ (BOOL)hasShowTips;
+ (void)setHasShowTips:(BOOL)hasShow;

// 工具方法
+ (UIColor *)colorFromHexString:(NSString *)hexString;

@end