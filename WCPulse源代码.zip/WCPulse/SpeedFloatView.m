#import "SpeedFloatView.h"

@implementation SpeedFloatView

static SpeedFloatView *sharedInstance = nil;

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^ {
        sharedInstance = [[SpeedFloatView alloc] init];
    });
    return sharedInstance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.alpha = 0.0;
        self.layer.cornerRadius = 12.0;
        self.clipsToBounds = YES;

        UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        self.blurView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
        self.blurView.alpha = 0.8;
        [self addSubview:self.blurView];

        self.speedLabel = [[UILabel alloc] init];
        self.speedLabel.textColor = [UIColor whiteColor];
        self.speedLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightBold];
        self.speedLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.speedLabel];

        self.animationView = [[UIView alloc] init];
        [self addSubview:self.animationView];

        for (int i = 100; i < 103; i++) {
            UIView *view = [[UIView alloc] init];
            view.backgroundColor = [UIColor clearColor];
            view.tag = i;
            [self.animationView addSubview:view];

            CAShapeLayer *layer = [CAShapeLayer layer];
            layer.fillColor = [UIColor whiteColor].CGColor;

            UIBezierPath *path = [UIBezierPath bezierPath];
            [path moveToPoint:CGPointMake(0, 4)];
            [path addLineToPoint:CGPointMake(0, 10)];
            [path addLineToPoint:CGPointMake(7, 7)];
            [path closePath];
            layer.path = path.CGPath;
            [view.layer addSublayer:layer];
        }
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.blurView.frame = self.bounds;

    self.speedLabel.frame = CGRectMake(12.0, 0, self.bounds.size.width - 5.0, self.bounds.size.height);

    CGFloat animationX = CGRectGetMaxX(self.speedLabel.frame) + 8.0;
    self.animationView.frame = CGRectMake(animationX, 0, 30.0, self.bounds.size.height);

    for (int i = 0; i < 3; i++) {
        UIView *view = [self.animationView viewWithTag:100 + i];
        CGFloat y = self.animationView.bounds.size.height / 2.0 - 5.0 + (i * 11);
        view.frame = CGRectMake(0, y, 8.0, 8.0);
        CAShapeLayer *layer = (CAShapeLayer *)view.layer.sublayers.firstObject;
        layer.position = CGPointMake(0, 0);
    }
}

- (void)startAnimation {
    [self.layer removeAllAnimations];
    for (UIView *subview in self.animationView.subviews) {
        [subview.layer removeAllAnimations];
    }

    for (int i = 100; i < 103; i++) {
        UIView *view = [self.animationView viewWithTag:i];
        view.alpha = 0.3; // 假设qword_43878是0.3，根据常见值
    }

    [UIView animateKeyframesWithDuration:1.0 delay:0.0 options:UIViewKeyframeAnimationOptionRepeat animations:^{
        [UIView addKeyframeWithRelativeStartTime:0.0 relativeDuration:0.25 animations:^{
            [self.animationView viewWithTag:100].alpha = 1.0;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.25 relativeDuration:0.25 animations:^{
            [self.animationView viewWithTag:100].alpha = 0.3;
            [self.animationView viewWithTag:101].alpha = 1.0;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.5 relativeDuration:0.25 animations:^{
            [self.animationView viewWithTag:101].alpha = 0.3;
            [self.animationView viewWithTag:102].alpha = 1.0;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.75 relativeDuration:0.25 animations:^{
            [self.animationView viewWithTag:102].alpha = 0.3;
        }];
    } completion:nil];
}

- (void)showWithSpeed:(float)speed isLeftSide:(BOOL)isLeftSide {
    self.isLeftSide = isLeftSide;
    self.speedLabel.text = [NSString stringWithFormat:@"%.1fx倍速", speed];
    [self setNeedsLayout];
    if (!self.superview) {
        UIViewController *topVC = [self topViewController];
        if (topVC) {
            [topVC.view addSubview:self];
            self.center = topVC.view.center;
            self.bounds = CGRectMake(0, 0, 0, 28.0); // 根据反汇编调整，实际宽度可能动态
        }
    }
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 1.0;
    }];
    [self startAnimation];
}

- (void)hide {
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0.0;
    } completion:^(BOOL finished) {
        if (finished) {
            [self removeFromSuperview];
        }
    }];
}

- (UIViewController *)topViewController {
    UIViewController *topVC = nil;
    
    // iOS 13+ 兼容性处理
    if (@available(iOS 13.0, *)) {
        NSSet *connectedScenes = [UIApplication sharedApplication].connectedScenes;
        for (UIScene *scene in connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]]) {
                UIWindowScene *windowScene = (UIWindowScene *)scene;
                for (UIWindow *window in windowScene.windows) {
                    if (window.isKeyWindow) {
                        topVC = window.rootViewController;
                        break;
                    }
                }
                if (topVC) break;
            }
        }
    } else {
        // iOS 13以下版本使用keyWindow
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        topVC = [UIApplication sharedApplication].keyWindow.rootViewController;
#pragma clang diagnostic pop
    }
    
    while (topVC.presentedViewController) {
        topVC = topVC.presentedViewController;
    }
    return topVC;
}

@end