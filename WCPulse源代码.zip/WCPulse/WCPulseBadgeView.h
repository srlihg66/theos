#import <UIKit/UIKit.h>

@interface WCPulseBadgeView : UIView

@property (nonatomic, strong) UILabel *badgeLabel;

+ (void)initialize;
+ (void)updateAllBadgeViews;

- (instancetype)initWithSegments:(NSArray *)segments;
- (void)updateBadgeCount:(NSInteger)count;
- (void)updateUI;
- (NSArray *)getSessionsBySegmentName:(NSString *)segmentName;
- (UIImage *)createBadgeImageWithSize:(CGSize)size;
- (void)handleBadgeSettingChanged;

@end