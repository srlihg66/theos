#import "WCPulseConfig.h"

@interface WCPulseConfig ()
@property (nonatomic, strong) NSMutableDictionary *configCache;
@end

@implementation WCPulseConfig

static WCPulseConfig *sharedConfig = nil;

+ (instancetype)shared {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedConfig = [[WCPulseConfig alloc] init];
    });
    return sharedConfig;
}

+ (instancetype)sharedConfig {
    return [self shared];
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.pulseEnabled = YES;
        self.pulseColor = [UIColor whiteColor];
        self.pulseWidth = 2.0;
        self.configCache = [NSMutableDictionary dictionary];
        
        // 初始化实例属性
        self.pluginVer = @"1.0.0";
        self.isUIModal = NO;
        self.myWxid = @"";
        self.needRedStyle = NO;
        self.showTopSession = NO;
        self.isEditing = NO;
        self.showIconMode = NO;
        self.showUnreadOnly = NO;
        self.needOpenEditMode = NO;
    }
    return self;
}

#pragma mark - 方法转发

+ (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector {
    NSMethodSignature *signature = [super methodSignatureForSelector:aSelector];
    if (!signature) {
        signature = [[self shared] methodSignatureForSelector:aSelector];
    }
    return signature;
}

+ (void)forwardInvocation:(NSInvocation *)anInvocation {
    WCPulseConfig *shared = [self shared];
    if ([shared respondsToSelector:anInvocation.selector]) {
        [anInvocation invokeWithTarget:shared];
    } else {
        [super forwardInvocation:anInvocation];
    }
}

#pragma mark - 配置文件管理

+ (NSString *)configFilePath {
    return [[self shared] configFilePath];
}

- (NSString *)configFilePath {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:@"WCPulseConfig.plist"];
}

+ (NSMutableDictionary *)configDictionary {
    return [[self shared] configDictionary];
}

- (NSMutableDictionary *)configDictionary {
    if (!self.configCache || self.configCache.count == 0) {
        NSString *path = [self configFilePath];
        NSMutableDictionary *config = [NSMutableDictionary dictionaryWithContentsOfFile:path];
        if (!config) {
            config = [NSMutableDictionary dictionary];
        }
        self.configCache = config;
    }
    return self.configCache;
}

+ (void)saveConfigDictionary:(NSMutableDictionary *)dictionary {
    [[self shared] saveConfigDictionary:dictionary];
}

- (void)saveConfigDictionary:(NSMutableDictionary *)dictionary {
    NSString *path = [self configFilePath];
    [dictionary writeToFile:path atomically:YES];
    self.configCache = [dictionary mutableCopy];
}

#pragma mark - 视频速度手势

+ (BOOL)enableVideoSpeedGesture {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableVideoSpeedGesture"] boolValue];
}

+ (void)setEnableVideoSpeedGesture:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableVideoSpeedGesture"];
    [self saveConfigDictionary:config];
}

#pragma mark - 时间标签

+ (BOOL)enableTimeLabel {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableTimeLabel"] boolValue];
}

+ (void)setEnableTimeLabel:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableTimeLabel"];
    [self saveConfigDictionary:config];
}

+ (UIColor *)timeLabelColor {
    NSMutableDictionary *config = [self configDictionary];
    NSString *hexString = [config objectForKey:@"timeLabelColor"];
    if (hexString) {
        return [self colorFromHexString:hexString];
    }
    return [UIColor labelColor];
}

+ (void)setTimeLabelColor:(UIColor *)color {
    if (!color) return;
    NSMutableDictionary *config = [self configDictionary];
    NSString *hexString = [self hexStringFromColor:color];
    [config setObject:hexString forKey:@"timeLabelColor"];
    [self saveConfigDictionary:config];
}

+ (void)setTimeLabelColorWithHexString:(NSString *)hexString {
    if (!hexString) return;
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:hexString forKey:@"timeLabelColor"];
    [self saveConfigDictionary:config];
}

+ (CGFloat)timeLabelFontSize {
    NSMutableDictionary *config = [self configDictionary];
    CGFloat fontSize = [[config objectForKey:@"timeLabelFontSize"] floatValue];
    return fontSize > 0 ? fontSize : 14.0;
}

+ (void)setTimeLabelFontSize:(CGFloat)fontSize {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(fontSize) forKey:@"timeLabelFontSize"];
    [self saveConfigDictionary:config];
}

+ (NSString *)timeLabelDateFormat {
    NSMutableDictionary *config = [self configDictionary];
    NSString *format = [config objectForKey:@"timeLabelDateFormat"];
    return format ? format : @"HH:mm";
}

+ (void)setTimeLabelDateFormat:(NSString *)format {
    if (!format) return;
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:format forKey:@"timeLabelDateFormat"];
    [self saveConfigDictionary:config];
}

+ (BOOL)enableTimeLabelBold {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableTimeLabelBold"] boolValue];
}

+ (void)setEnableTimeLabelBold:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableTimeLabelBold"];
    [self saveConfigDictionary:config];
}

+ (BOOL)hideTimeLabel {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"hideTimeLabel"] boolValue];
}

+ (void)setHideTimeLabel:(BOOL)hide {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(hide) forKey:@"hideTimeLabel"];
    [self saveConfigDictionary:config];
}

+ (CGFloat)timeLabelHeight {
    NSMutableDictionary *config = [self configDictionary];
    CGFloat height = [[config objectForKey:@"timeLabelHeight"] floatValue];
    return height > 0 ? height : 20.0;
}

+ (void)setTimeLabelHeight:(CGFloat)height {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(height) forKey:@"timeLabelHeight"];
    [self saveConfigDictionary:config];
}

#pragma mark - 速度文本

+ (NSString *)leftSpeedText {
    NSMutableDictionary *config = [self configDictionary];
    NSString *text = [config objectForKey:@"leftSpeedText"];
    return text ? text : @"0.5x";
}

+ (void)setLeftSpeedText:(NSString *)text {
    if (!text) return;
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:text forKey:@"leftSpeedText"];
    [self saveConfigDictionary:config];
}

+ (NSString *)rightSpeedText {
    NSMutableDictionary *config = [self configDictionary];
    NSString *text = [config objectForKey:@"rightSpeedText"];
    return text ? text : @"2.0x";
}

+ (void)setRightSpeedText:(NSString *)text {
    if (!text) return;
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:text forKey:@"rightSpeedText"];
    [self saveConfigDictionary:config];
}

#pragma mark - 消息防撤回

+ (BOOL)enableMessageNoRevoke {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableMessageNoRevoke"] boolValue];
}

+ (void)setEnableMessageNoRevoke:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableMessageNoRevoke"];
    [self saveConfigDictionary:config];
}

+ (BOOL)messageNoRevokeNoTip {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"messageNoRevokeNoTip"] boolValue];
}

+ (void)setMessageNoRevokeNoTip:(BOOL)noTip {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(noTip) forKey:@"messageNoRevokeNoTip"];
    [self saveConfigDictionary:config];
}

+ (UIColor *)messageNoRevokeColor {
    NSMutableDictionary *config = [self configDictionary];
    NSString *hexString = [config objectForKey:@"messageNoRevokeColor"];
    if (hexString) {
        return [self colorFromHexString:hexString];
    }
    return [UIColor redColor];
}

+ (void)setMessageNoRevokeColor:(UIColor *)color {
    if (!color) return;
    NSMutableDictionary *config = [self configDictionary];
    NSString *hexString = [self hexStringFromColor:color];
    [config setObject:hexString forKey:@"messageNoRevokeColor"];
    [self saveConfigDictionary:config];
}

+ (NSString *)messageNoRevokeDateFormat {
    NSMutableDictionary *config = [self configDictionary];
    NSString *format = [config objectForKey:@"messageNoRevokeDateFormat"];
    return format ? format : @"yyyy-MM-dd HH:mm:ss";
}

+ (void)setMessageNoRevokeDateFormat:(NSString *)format {
    if (!format) return;
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:format forKey:@"messageNoRevokeDateFormat"];
    [self saveConfigDictionary:config];
}

+ (NSString *)messageNoRevokeFormat {
    NSMutableDictionary *config = [self configDictionary];
    NSString *format = [config objectForKey:@"messageNoRevokeFormat"];
    return format ? format : @"[已撤回] %@";
}

+ (void)setMessageNoRevokeFormat:(NSString *)format {
    if (!format) return;
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:format forKey:@"messageNoRevokeFormat"];
    [self saveConfigDictionary:config];
}

+ (BOOL)messageNoRevokeBottom {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"messageNoRevokeBottom"] boolValue];
}

+ (void)setMessageNoRevokeBottom:(BOOL)bottom {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(bottom) forKey:@"messageNoRevokeBottom"];
    [self saveConfigDictionary:config];
}

#pragma mark - 功能开关

+ (BOOL)enableForward {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableForward"] boolValue];
}

+ (void)setEnableForward:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableForward"];
    [self saveConfigDictionary:config];
}

+ (BOOL)enableCompatibilityTip {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableCompatibilityTip"] boolValue];
}

+ (void)setEnableCompatibilityTip:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableCompatibilityTip"];
    [self saveConfigDictionary:config];
}

+ (BOOL)enablePreventDeleteChatRecord {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enablePreventDeleteChatRecord"] boolValue];
}

+ (void)setEnablePreventDeleteChatRecord:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enablePreventDeleteChatRecord"];
    [self saveConfigDictionary:config];
}

+ (BOOL)enablePopPreview {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enablePopPreview"] boolValue];
}

+ (void)setEnablePopPreview:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enablePopPreview"];
    [self saveConfigDictionary:config];
}

+ (BOOL)needConvert {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"needConvert"] boolValue];
}

+ (void)setNeedConvert:(BOOL)need {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(need) forKey:@"needConvert"];
    [self saveConfigDictionary:config];
}

+ (BOOL)enableCall2Confirm {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableCall2Confirm"] boolValue];
}

+ (void)setEnableCall2Confirm:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableCall2Confirm"];
    [self saveConfigDictionary:config];
}

#pragma mark - 自动功能

+ (BOOL)enableAutoPlayBaseMsgLivePhoto {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableAutoPlayBaseMsgLivePhoto"] boolValue];
}

+ (void)setEnableAutoPlayBaseMsgLivePhoto:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableAutoPlayBaseMsgLivePhoto"];
    [self saveConfigDictionary:config];
}

+ (BOOL)enableAutoSelectOriginalImage {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableAutoSelectOriginalImage"] boolValue];
}

+ (void)setEnableAutoSelectOriginalImage:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableAutoSelectOriginalImage"];
    [self saveConfigDictionary:config];
}

+ (BOOL)enableAutoSelectLivePhoto {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableAutoSelectLivePhoto"] boolValue];
}

+ (void)setEnableAutoSelectLivePhoto:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableAutoSelectLivePhoto"];
    [self saveConfigDictionary:config];
}

#pragma mark - 群组管理

+ (NSArray *)groupFilterList {
    NSMutableDictionary *config = [self configDictionary];
    NSArray *list = [config objectForKey:@"groupFilterList"];
    return list ? list : @[];
}

+ (void)setGroupFilterList:(NSArray *)list {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:(list ?: @[]) forKey:@"groupFilterList"];
    [self saveConfigDictionary:config];
}

+ (BOOL)enableGroupFilter {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"enableGroupFilter"] boolValue];
}

+ (void)setEnableGroupFilter:(BOOL)enable {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(enable) forKey:@"enableGroupFilter"];
    [self saveConfigDictionary:config];
}

+ (NSDictionary *)groupNameMapping {
    NSMutableDictionary *config = [self configDictionary];
    NSDictionary *mapping = [config objectForKey:@"groupNameMapping"];
    return mapping ? mapping : @{};
}

+ (void)setGroupNameMapping:(NSDictionary *)mapping {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:(mapping ?: @{}) forKey:@"groupNameMapping"];
    [self saveConfigDictionary:config];
}

+ (NSString *)mappedGroupName:(NSString *)originalName {
    if (!originalName) return @"";
    NSDictionary *mapping = [self groupNameMapping];
    NSString *mapped = mapping[originalName];
    return mapped ? mapped : originalName;
}

#pragma mark - 显示设置

+ (BOOL)isShowDonation {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"isShowDonation"] boolValue];
}

+ (void)setIsShowDonation:(BOOL)show {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(show) forKey:@"isShowDonation"];
    [self saveConfigDictionary:config];
}

+ (BOOL)hideGroupIndicator {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"hideGroupIndicator"] boolValue];
}

+ (void)setHideGroupIndicator:(BOOL)hide {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(hide) forKey:@"hideGroupIndicator"];
    [self saveConfigDictionary:config];
}

+ (BOOL)hideGroupBadge {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"hideGroupBadge"] boolValue];
}

+ (void)setHideGroupBadge:(BOOL)hide {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(hide) forKey:@"hideGroupBadge"];
    [self saveConfigDictionary:config];
}

+ (BOOL)hideAllGroupBadge {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"hideAllGroupBadge"] boolValue];
}

+ (void)setHideAllGroupBadge:(BOOL)hide {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(hide) forKey:@"hideAllGroupBadge"];
    [self saveConfigDictionary:config];
}

#pragma mark - 工具方法

+ (NSString *)hexStringFromColor:(UIColor *)color {
    if (!color) return @"#000000";
    
    CGFloat red, green, blue, alpha;
    [color getRed:&red green:&green blue:&blue alpha:&alpha];
    
    int r = (int)(red * 255.0);
    int g = (int)(green * 255.0);
    int b = (int)(blue * 255.0);
    
    return [NSString stringWithFormat:@"#%02X%02X%02X", r, g, b];
}

+ (UIColor *)colorFromHexString:(NSString *)hexString {
    if (!hexString || hexString.length == 0) {
        return [UIColor blackColor];
    }
    
    NSString *cleanString = [hexString stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if (cleanString.length != 6) {
        return [UIColor blackColor];
    }
    
    NSScanner *scanner = [NSScanner scannerWithString:cleanString];
    unsigned hexNum;
    if (![scanner scanHexInt:&hexNum]) {
        return [UIColor blackColor];
    }
    
    return [UIColor colorWithRed:((hexNum & 0xFF0000) >> 16) / 255.0
                           green:((hexNum & 0x00FF00) >> 8) / 255.0
                            blue:(hexNum & 0x0000FF) / 255.0
                           alpha:1.0];
}

+ (BOOL)hasShowTips {
    NSMutableDictionary *config = [self configDictionary];
    return [[config objectForKey:@"hasShowTips"] boolValue];
}

+ (void)setHasShowTips:(BOOL)hasShow {
    NSMutableDictionary *config = [self configDictionary];
    [config setObject:@(hasShow) forKey:@"hasShowTips"];
    [self saveConfigDictionary:config];
}

#pragma mark - NSUserDefaults-style methods

+ (BOOL)boolForKey:(NSString *)key {
    NSMutableDictionary *config = [self configDictionary];
    NSNumber *value = config[key];
    return value ? [value boolValue] : NO;
}

+ (void)setBool:(BOOL)value forKey:(NSString *)key {
    NSMutableDictionary *config = [self configDictionary];
    config[key] = @(value);
    [self saveConfigDictionary:config];
}

+ (NSInteger)integerForKey:(NSString *)key {
    NSMutableDictionary *config = [self configDictionary];
    NSNumber *value = config[key];
    return value ? [value integerValue] : 0;
}

+ (void)setInteger:(NSInteger)value forKey:(NSString *)key {
    NSMutableDictionary *config = [self configDictionary];
    config[key] = @(value);
    [self saveConfigDictionary:config];
}

+ (NSArray *)arrayForKey:(NSString *)key {
    NSMutableDictionary *config = [self configDictionary];
    return config[key];
}

+ (void)setArray:(NSArray *)value forKey:(NSString *)key {
    NSMutableDictionary *config = [self configDictionary];
    config[key] = value;
    [self saveConfigDictionary:config];
}

+ (CGFloat)floatForKey:(NSString *)key defaultValue:(CGFloat)defaultValue {
    NSMutableDictionary *config = [self configDictionary];
    NSNumber *value = config[key];
    return value ? [value floatValue] : defaultValue;
}

+ (void)setFloat:(CGFloat)value forKey:(NSString *)key {
    NSMutableDictionary *config = [self configDictionary];
    config[key] = @(value);
    [self saveConfigDictionary:config];
}

+ (UIColor *)colorForKey:(NSString *)key defaultValue:(UIColor *)defaultValue {
    NSMutableDictionary *config = [self configDictionary];
    NSData *colorData = config[key];
    if (colorData) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        return [NSKeyedUnarchiver unarchiveObjectWithData:colorData];
#pragma clang diagnostic pop
    }
    return defaultValue;
}

+ (void)setColor:(UIColor *)color forKey:(NSString *)key {
    NSMutableDictionary *config = [self configDictionary];
    if (color) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:color];
#pragma clang diagnostic pop
        config[key] = colorData;
    } else {
        [config removeObjectForKey:key];
    }
    [self saveConfigDictionary:config];
}

+ (BOOL)isTempAddAll { return [self boolForKey:@"isTempAddAll"]; }
+ (void)setIsTempAddAll:(BOOL)tempAdd { [self setBool:tempAdd forKey:@"isTempAddAll"]; }
+ (NSInteger)defaultGroupIndex { return [self integerForKey:@"defaultGroupIndex"]; }
+ (void)setDefaultGroupIndex:(NSInteger)index { [self setInteger:index forKey:@"defaultGroupIndex"]; }
+ (BOOL)removeServiceAccount { return [self boolForKey:@"removeServiceAccount"]; }
+ (void)setRemoveServiceAccount:(BOOL)remove { [self setBool:remove forKey:@"removeServiceAccount"]; }
+ (BOOL)hasShownWelcome { return [self boolForKey:@"hasShownWelcome"]; }
+ (void)setHasShownWelcome:(BOOL)shown { [self setBool:shown forKey:@"hasShownWelcome"]; }
+ (BOOL)enableTopFilter { return [self boolForKey:@"enableTopFilter"]; }
+ (void)setEnableTopFilter:(BOOL)enable { [self setBool:enable forKey:@"enableTopFilter"]; }
+ (BOOL)enableGlobalSwitchGroupGesture { return [self boolForKey:@"enableGlobalSwitchGroupGesture"]; }
+ (void)setEnableGlobalSwitchGroupGesture:(BOOL)enable { [self setBool:enable forKey:@"enableGlobalSwitchGroupGesture"]; }
+ (NSArray *)customGroupList { return [self arrayForKey:@"customGroupList"]; }
+ (void)setCustomGroupList:(NSArray *)list { [self setArray:list forKey:@"customGroupList"]; }
+ (CGFloat)vibrationStrength { return [self floatForKey:@"vibrationStrength" defaultValue:1.0]; }
+ (void)setVibrationStrength:(CGFloat)strength { [self setFloat:strength forKey:@"vibrationStrength"]; }
+ (BOOL)enableGroupTransitionAnimation { return [self boolForKey:@"enableGroupTransitionAnimation"]; }
+ (void)setEnableGroupTransitionAnimation:(BOOL)enable { [self setBool:enable forKey:@"enableGroupTransitionAnimation"]; }

// 翻译文本背景
+ (BOOL)removeTranslatedTextBg { return [self boolForKey:@"removeTranslatedTextBg"]; }
+ (void)setRemoveTranslatedTextBg:(BOOL)remove { [self setBool:remove forKey:@"removeTranslatedTextBg"]; }

// 版本信息
+ (NSString *)pluginVer {
    NSMutableDictionary *config = [self configDictionary];
    NSString *version = config[@"pluginVer"];
    return version ?: @"1.0.0";
}
+ (void)setPluginVer:(NSString *)version {
    NSMutableDictionary *config = [self configDictionary];
    config[@"pluginVer"] = version;
    [self saveConfigDictionary:config];
}

// 过滤重复联系人
+ (BOOL)filterDuplicateContacts { return [self boolForKey:@"filterDuplicateContacts"]; }
+ (void)setFilterDuplicateContacts:(BOOL)filter { [self setBool:filter forKey:@"filterDuplicateContacts"]; }

// 群组指示器样式
+ (NSInteger)groupIndicatorStyle { return [self integerForKey:@"groupIndicatorStyle"]; }
+ (void)setGroupIndicatorStyle:(NSInteger)style { [self setInteger:style forKey:@"groupIndicatorStyle"]; }

// 隐藏群组背景色
+ (BOOL)hideGroupBackgroundColor { return [self boolForKey:@"hideGroupBackgroundColor"]; }
+ (void)setHideGroupBackgroundColor:(BOOL)hide { [self setBool:hide forKey:@"hideGroupBackgroundColor"]; }

// 首页圆角
+ (BOOL)enableHomeCorner { return [self boolForKey:@"enableHomeCorner"]; }
+ (void)setEnableHomeCorner:(BOOL)enable { [self setBool:enable forKey:@"enableHomeCorner"]; }
+ (CGFloat)homeCornerRadius { return [self floatForKey:@"homeCornerRadius" defaultValue:8.0]; }
+ (void)setHomeCornerRadius:(CGFloat)radius { [self setFloat:radius forKey:@"homeCornerRadius"]; }
+ (CGFloat)homeCornerHorizontalPadding { return [self floatForKey:@"homeCornerHorizontalPadding" defaultValue:16.0]; }
+ (void)setHomeCornerHorizontalPadding:(CGFloat)padding { [self setFloat:padding forKey:@"homeCornerHorizontalPadding"]; }
+ (CGFloat)homeCornerVerticalPadding { return [self floatForKey:@"homeCornerVerticalPadding" defaultValue:8.0]; }
+ (void)setHomeCornerVerticalPadding:(CGFloat)padding { [self setFloat:padding forKey:@"homeCornerVerticalPadding"]; }
+ (UIColor *)homeCornerLightColor { return [self colorForKey:@"homeCornerLightColor" defaultValue:[UIColor whiteColor]]; }
+ (void)setHomeCornerLightColor:(UIColor *)color { [self setColor:color forKey:@"homeCornerLightColor"]; }
+ (UIColor *)homeCornerDarkColor { return [self colorForKey:@"homeCornerDarkColor" defaultValue:[UIColor blackColor]]; }
+ (void)setHomeCornerDarkColor:(UIColor *)color { [self setColor:color forKey:@"homeCornerDarkColor"]; }

#pragma mark - Color Settings (simplified implementations)
+ (UIColor *)groupBackgroundColor { return [self colorForKey:@"groupBackgroundColor" defaultValue:[UIColor systemBackgroundColor]]; }
+ (void)setGroupBackgroundColor:(UIColor *)color { [self setColor:color forKey:@"groupBackgroundColor"]; }

// 群组指示器颜色
+ (UIColor *)groupIndicatorColor { return [self colorForKey:@"groupIndicatorColor" defaultValue:[UIColor systemBlueColor]]; }
+ (void)setGroupIndicatorColor:(UIColor *)color { [self setColor:color forKey:@"groupIndicatorColor"]; }

// 群组字体颜色
+ (UIColor *)groupFontColor { return [self colorForKey:@"groupFontColor" defaultValue:[UIColor labelColor]]; }
+ (void)setGroupFontColor:(UIColor *)color { [self setColor:color forKey:@"groupFontColor"]; }
+ (UIColor *)groupUnselectedFontColor { return [self colorForKey:@"groupUnselectedFontColor" defaultValue:[UIColor secondaryLabelColor]]; }
+ (void)setGroupUnselectedFontColor:(UIColor *)color { [self setColor:color forKey:@"groupUnselectedFontColor"]; }

// 群组颜色设置 - 深色模式
+ (UIColor *)groupBackgroundColorDark { return [self colorForKey:@"groupBackgroundColorDark" defaultValue:[UIColor systemBackgroundColor]]; }
+ (void)setGroupBackgroundColorDark:(UIColor *)color { [self setColor:color forKey:@"groupBackgroundColorDark"]; }
+ (UIColor *)groupIndicatorColorDark { return [self colorForKey:@"groupIndicatorColorDark" defaultValue:[UIColor systemBlueColor]]; }
+ (void)setGroupIndicatorColorDark:(UIColor *)color { [self setColor:color forKey:@"groupIndicatorColorDark"]; }
+ (UIColor *)groupFontColorDark { return [self colorForKey:@"groupFontColorDark" defaultValue:[UIColor labelColor]]; }
+ (void)setGroupFontColorDark:(UIColor *)color { [self setColor:color forKey:@"groupFontColorDark"]; }
+ (UIColor *)groupUnselectedFontColorDark { return [self colorForKey:@"groupUnselectedFontColorDark" defaultValue:[UIColor secondaryLabelColor]]; }
+ (void)setGroupUnselectedFontColorDark:(UIColor *)color { [self setColor:color forKey:@"groupUnselectedFontColorDark"]; }

// 群组字体大小
+ (CGFloat)groupFontSize { return [self floatForKey:@"groupFontSize" defaultValue:16.0]; }
+ (void)setGroupFontSize:(CGFloat)size { [self setFloat:size forKey:@"groupFontSize"]; }

@end