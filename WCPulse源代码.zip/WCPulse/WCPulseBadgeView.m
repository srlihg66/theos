#import "WCPulseBadgeView.h"
#import "WCPulseSessionMgr.h"

@implementation WCPulseBadgeView

- (instancetype)init {
    self = [super init];
    if (self) {
        self.badgeLabel = [[UILabel alloc] initWithFrame:self.bounds];
        self.badgeLabel.textAlignment = NSTextAlignmentCenter;
        self.badgeLabel.textColor = [UIColor whiteColor];
        self.badgeLabel.backgroundColor = [UIColor redColor];
        self.badgeLabel.layer.cornerRadius = self.bounds.size.height / 2;
        self.badgeLabel.clipsToBounds = YES;
        [self addSubview:self.badgeLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.badgeLabel.frame = self.bounds;
    self.badgeLabel.layer.cornerRadius = self.bounds.size.height / 2;
}

+ (void)initialize {
    // 初始化代码
    [super initialize];
}

+ (void)updateAllBadgeViews {
    // 更新所有徽章视图
    [[NSNotificationCenter defaultCenter] postNotificationName:@"WCPulseBadgeUpdateNotification" object:nil];
}

- (instancetype)initWithSegments:(NSArray *)segments {
    self = [super init];
    if (self) {
        // 根据segments初始化徽章视图
        [self setupBadgeViewWithSegments:segments];
        
        // 监听徽章设置变化
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(handleBadgeSettingChanged) 
                                                     name:@"WCPulseBadgeSettingChangedNotification" 
                                                   object:nil];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)setupBadgeViewWithSegments:(NSArray *)segments {
    // 设置徽章视图
    self.backgroundColor = [UIColor redColor];
    self.layer.cornerRadius = 10;
    self.clipsToBounds = YES;
    
    if (!self.badgeLabel) {
        self.badgeLabel = [[UILabel alloc] init];
        self.badgeLabel.textColor = [UIColor whiteColor];
        self.badgeLabel.font = [UIFont systemFontOfSize:12];
        self.badgeLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.badgeLabel];
    }
}

- (void)updateBadgeCount:(NSInteger)count {
    if (count > 0) {
        self.hidden = NO;
        if (count > 99) {
            self.badgeLabel.text = @"99+";
        } else {
            self.badgeLabel.text = [NSString stringWithFormat:@"%ld", (long)count];
        }
        [self updateUI];
    } else {
        self.hidden = YES;
    }
}

- (void)updateUI {
    // 更新UI布局
    CGSize textSize = [self.badgeLabel.text sizeWithAttributes:@{NSFontAttributeName: self.badgeLabel.font}];
    CGFloat width = MAX(20, textSize.width + 8);
    CGFloat height = 20;
    
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, width, height);
    self.badgeLabel.frame = self.bounds;
    self.layer.cornerRadius = height / 2;
}

- (NSArray *)getSessionsBySegmentName:(NSString *)segmentName {
    // 根据段名获取会话列表（真实过滤逻辑）
    WCPulseSessionMgr *sessionMgr = [WCPulseSessionMgr shared];

    // 使用 SessionMgr 的缓存及加载逻辑，使用 allSessions 获取主会话列表
    NSArray *rawSessions = sessionMgr.allSessions;
    if (![rawSessions isKindOfClass:[NSArray class]] || rawSessions.count == 0) {
        [sessionMgr reloadSessions];
        rawSessions = sessionMgr.allSessions;
    }
    if (![rawSessions isKindOfClass:[NSArray class]]) {
        rawSessions = @[];
    }

    // 过滤：先取置顶（needTop:YES），再取非置顶（needTop:NO），拼接返回
    NSArray *topSessions = [sessionMgr filterSessions:rawSessions withGroupName:segmentName needTop:YES];
    NSArray *normalSessions = [sessionMgr filterSessions:rawSessions withGroupName:segmentName needTop:NO];
    if (!topSessions) topSessions = @[];
    if (!normalSessions) normalSessions = @[];

    return [topSessions arrayByAddingObjectsFromArray:normalSessions];
}

- (UIImage *)createBadgeImageWithSize:(CGSize)size {
    // 创建徽章图片
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // 绘制红色圆形背景
    CGContextSetFillColorWithColor(context, [UIColor redColor].CGColor);
    CGContextFillEllipseInRect(context, CGRectMake(0, 0, size.width, size.height));
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

- (void)handleBadgeSettingChanged {
    // 处理徽章设置变化
    [self updateUI];
}

@end