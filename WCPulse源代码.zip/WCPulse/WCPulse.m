#import "WCPulse.h"
#import <objc/runtime.h>

@interface WCPulse ()
@property (nonatomic, strong) WCPulseConfig *config;
@property (nonatomic, strong) WCPulseHelper *helper;
@property (nonatomic, strong) WCPulseSessionMgr *sessionMgr;
@property (nonatomic, strong) SpeedFloatView *speedFloatView;
@property (nonatomic, assign) BOOL isInitialized;
@end

@implementation WCPulse

+ (instancetype)sharedInstance {
    static WCPulse *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[WCPulse alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _isInitialized = NO;
        [self setupComponents];
    }
    return self;
}

- (void)setupComponents {
    self.config = [WCPulseConfig shared];
    self.helper = [WCPulseHelper shared];
    self.sessionMgr = [WCPulseSessionMgr shared];
    self.speedFloatView = [SpeedFloatView sharedInstance];
}

- (void)initialize {
    if (self.isInitialized) {
        return;
    }
    
    [self loadConfiguration];
    [self installHooks];
    [self.sessionMgr setupDefaultGroups];
    
    self.isInitialized = YES;
    NSLog(@"WCPulse插件初始化完成");
}

- (void)applicationDidFinishLaunching {
    [self initialize];
    
    // 显示初始化提示
    if (![WCPulseConfig hasShowTips]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [WCPulseHelper showModernToast:@"WCPulse插件已加载"];
            [WCPulseConfig setHasShowTips:YES];
        });
    }
}

- (void)applicationWillTerminate {
    [self saveConfiguration];
    [self uninstallHooks];
    NSLog(@"WCPulse插件已卸载");
}

#pragma mark - 视频速度控制
- (void)enableVideoSpeedControl:(BOOL)enable {
    [WCPulseConfig setEnableVideoSpeedGesture:enable];
    NSLog(@"视频速度控制: %@", enable ? @"启用" : @"禁用");
}

- (void)showSpeedIndicator:(NSString *)speed position:(CGPoint)position {
    BOOL isLeftSide = position.x < [UIScreen mainScreen].bounds.size.width / 2;
    float speedValue = [speed floatValue];
    [self.speedFloatView showWithSpeed:speedValue isLeftSide:isLeftSide];
}

- (void)hideSpeedIndicator {
    [self.speedFloatView hide];
}

#pragma mark - 消息防撤回
- (void)enableMessageNoRevoke:(BOOL)enable {
    [WCPulseConfig setEnableMessageNoRevoke:enable];
    NSLog(@"消息防撤回: %@", enable ? @"启用" : @"禁用");
}

- (void)handleMessageRevoke:(id)message {
    if ([WCPulseConfig enableMessageNoRevoke]) {
        // 阻止消息撤回
        NSLog(@"阻止消息撤回");
        
        if (![WCPulseConfig messageNoRevokeNoTip]) {
            [WCPulseHelper showModernToast:@"已阻止消息撤回"];
        }
    }
}

#pragma mark - 群组管理
- (void)showGroupSettings {
    WCPulseGroupSettingViewController *settingVC = [[WCPulseGroupSettingViewController alloc] init];
    UIViewController *topVC = [WCPulseHelper findTopVC];
    if (topVC) {
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:settingVC];
        [topVC presentViewController:navController animated:YES completion:nil];
    }
}

- (void)reloadSessionGroups {
    [self.sessionMgr reloadSessions];
    [self refreshAllBadges];
}

#pragma mark - 徽章管理
- (void)updateBadgeCount:(NSInteger)count forGroup:(NSString *)groupName {
    // 更新指定群组的徽章数量
    [WCPulseBadgeView updateAllBadgeViews];
    NSLog(@"更新群组 %@ 徽章数量: %ld", groupName, (long)count);
}

- (void)refreshAllBadges {
    [WCPulseBadgeView updateAllBadgeViews];
}

#pragma mark - 配置管理
- (void)loadConfiguration {
    // 配置已经通过WCPulseConfig自动加载
    NSLog(@"配置加载完成");
}

- (void)saveConfiguration {
    // 配置会自动保存，这里可以做额外的保存逻辑
    NSLog(@"配置保存完成");
}

- (void)resetToDefaultConfiguration {
    // 重置为默认配置
    [WCPulseConfig setEnableVideoSpeedGesture:NO];
    [WCPulseConfig setEnableTimeLabel:YES];
    [WCPulseConfig setEnableMessageNoRevoke:NO];
    [WCPulseConfig setLeftSpeedText:@"0.5x"];
    [WCPulseConfig setRightSpeedText:@"2.0x"];
    [WCPulseConfig setTimeLabelFontSize:14.0];
    [WCPulseConfig setTimeLabelDateFormat:@"HH:mm"];
    
    NSLog(@"配置已重置为默认值");
}

#pragma mark - Hook管理
- (void)installHooks {
    // 通过WCPulseLoader安装各种Method Swizzling hooks
    [[NSNotificationCenter defaultCenter] postNotificationName:@"WCPulseInstallHooks" object:nil];
    NSLog(@"Hooks安装完成");
}

- (void)uninstallHooks {
    // 通过WCPulseLoader卸载hooks
    [[NSNotificationCenter defaultCenter] postNotificationName:@"WCPulseUninstallHooks" object:nil];
    NSLog(@"Hooks卸载完成");
}

@end