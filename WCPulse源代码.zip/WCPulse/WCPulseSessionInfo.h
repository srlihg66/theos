#import <Foundation/Foundation.h>

@interface WCPulseSessionInfo : NSObject

@property (nonatomic, strong) NSString *sessionId;
@property (nonatomic, strong) NSDate *startTime;
@property (nonatomic, strong) NSDate *endTime;
@property (nonatomic, strong) NSString *groupName;
@property (nonatomic, strong) NSArray *normalSessions;
@property (nonatomic, strong) NSArray *topSessions;

- (instancetype)initWithGroupName:(NSString *)groupName;

@end