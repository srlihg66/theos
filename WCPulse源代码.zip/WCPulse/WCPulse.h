#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "WCPulseConfig.h"
#import "WCPulseHelper.h"
#import "WCPulseSessionMgr.h"
#import "SpeedFloatView.h"
#import "WCPulseBadgeView.h"
#import "WCPulseGroupSettingViewController.h"

@interface WCPulse : NSObject

+ (instancetype)sharedInstance;

// 插件初始化和生命周期
- (void)initialize;
- (void)applicationDidFinishLaunching;
- (void)applicationWillTerminate;

// 主要功能接口
- (void)enableVideoSpeedControl:(BOOL)enable;
- (void)showSpeedIndicator:(NSString *)speed position:(CGPoint)position;
- (void)hideSpeedIndicator;

// 消息防撤回
- (void)enableMessageNoRevoke:(BOOL)enable;
- (void)handleMessageRevoke:(id)message;

// 群组管理
- (void)showGroupSettings;
- (void)reloadSessionGroups;

// 徽章管理
- (void)updateBadgeCount:(NSInteger)count forGroup:(NSString *)groupName;
- (void)refreshAllBadges;

// 配置管理
- (void)loadConfiguration;
- (void)saveConfiguration;
- (void)resetToDefaultConfiguration;

// Hook相关方法
- (void)installHooks;
- (void)uninstallHooks;

@end