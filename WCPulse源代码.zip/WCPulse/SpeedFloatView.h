#import <UIKit/UIKit.h>

@interface SpeedFloatView : UIView

@property (nonatomic, strong) UIVisualEffectView *blurView;
@property (nonatomic, strong) UILabel *speedLabel;
@property (nonatomic, strong) UIView *animationView;
@property (nonatomic, assign) BOOL isLeftSide;

+ (instancetype)sharedInstance;

- (void)layoutSubviews;
- (void)startAnimation;
- (void)showWithSpeed:(float)speed isLeftSide:(BOOL)isLeftSide;
- (void)hide;
- (UIViewController *)topViewController;

@end