#import "WCPulseSessionInfo.h"

@implementation WCPulseSessionInfo

- (instancetype)initWithGroupName:(NSString *)groupName {
    self = [super init];
    if (self) {
        _groupName = groupName;
        _normalSessions = [NSArray array];
        _topSessions = [NSArray array];
        _startTime = [NSDate date];
    }
    return self;
}

@end