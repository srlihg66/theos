#import "WCPulseLoader.h"
#import "WCPulse.h"
#import "WCPulseConfig.h"
#import "WCPulseHelper.h"
#import <objc/runtime.h>
#import <dlfcn.h>
#import <UIKit/UIKit.h>

@interface WCPulseLoader ()
@property (nonatomic, assign) BOOL isLoaded;
@property (nonatomic, assign) BOOL hooksInstalled;
@end

@implementation WCPulseLoader

+ (instancetype)sharedLoader {
    static WCPulseLoader *loader = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        loader = [[WCPulseLoader alloc] init];
    });
    return loader;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _isLoaded = NO;
        _hooksInstalled = NO;
        
        // 监听应用生命周期
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(applicationDidFinishLaunching:)
                                                     name:UIApplicationDidFinishLaunchingNotification
                                                   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(applicationWillTerminate:)
                                                     name:UIApplicationWillTerminateNotification
                                                   object:nil];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - 插件生命周期

- (void)loadPlugin {
    if (self.isLoaded) {
        NSLog(@"[WCPulseLoader] 插件已经加载");
        return;
    }
    
    NSLog(@"[WCPulseLoader] 开始加载WCPulse插件...");
    
    @try {
        // 检查微信版本兼容性
        if (![self checkWeChatCompatibility]) {
            NSLog(@"[WCPulseLoader] 微信版本不兼容，停止加载插件");
            return;
        }
        
        // 安装Hooks
        [self installAllHooks];
        
        // 初始化主插件
        [[WCPulse sharedInstance] initialize];
        
        // 监听主插件的Hook管理通知
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(handleInstallHooksNotification:)
                                                     name:@"WCPulseInstallHooks"
                                                   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(handleUninstallHooksNotification:)
                                                     name:@"WCPulseUninstallHooks"
                                                   object:nil];
        
        self.isLoaded = YES;
        NSLog(@"[WCPulseLoader] WCPulse插件加载成功");
        
    } @catch (NSException *exception) {
        NSLog(@"[WCPulseLoader] 插件加载失败: %@", exception.reason);
        [self unloadPlugin];
    }
}

- (void)unloadPlugin {
    if (!self.isLoaded) {
        return;
    }
    
    NSLog(@"[WCPulseLoader] 卸载WCPulse插件...");
    
    @try {
        // 卸载Hooks
        [self uninstallAllHooks];
        
        // 取消通知监听（由loadPlugin中添加）
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WCPulseInstallHooks" object:nil];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WCPulseUninstallHooks" object:nil];
        
        // 清理资源
        [[WCPulse sharedInstance] applicationWillTerminate];
        
        self.isLoaded = NO;
        NSLog(@"[WCPulseLoader] WCPulse插件卸载成功");
        
    } @catch (NSException *exception) {
        NSLog(@"[WCPulseLoader] 插件卸载失败: %@", exception.reason);
    }
}

#pragma mark - Hook管理

- (void)installAllHooks {
    if (self.hooksInstalled) {
        return;
    }
    
    NSLog(@"[WCPulseLoader] 安装Hooks...");
    
    @try {
        // 安装与WCPulse核心功能相关的Swizzling，包括：
        // 1) 消息防撤回（MessageRevokeMgr onRevokeMsg:）
        // 2) 视频播放速度与手势（WCPlayerView、AVPlayerViewController 等）
        // 3) 会话列表分组与标记（MainSessionViewController、SessionCellView、MMNewSessionMgr 等）
        [self hookMessageMethods];
        [self hookVideoMethods];
        [self hookSessionMethods];
        
        self.hooksInstalled = YES;
        NSLog(@"[WCPulseLoader] Hooks安装完成");
        
    } @catch (NSException *exception) {
        NSLog(@"[WCPulseLoader] Hooks安装失败: %@", exception.reason);
        @throw exception;
    }
}

- (void)uninstallAllHooks {
    if (!self.hooksInstalled) {
        return;
    }
    
    NSLog(@"[WCPulseLoader] 卸载Hooks...");
    
    @try {
        // 插件卸载时无需额外操作，swizzling会随着动态库卸载而失效        
        self.hooksInstalled = NO;
        NSLog(@"[WCPulseLoader] Hooks卸载完成");
        
    } @catch (NSException *exception) {
        NSLog(@"[WCPulseLoader] Hooks卸载失败: %@", exception.reason);
    }
}

// 处理来自主插件的Hook安装/卸载通知
- (void)handleInstallHooksNotification:(NSNotification *)notification {
    NSLog(@"[WCPulseLoader] 收到安装Hooks通知");
    [self installAllHooks];
}

- (void)handleUninstallHooksNotification:(NSNotification *)notification {
    NSLog(@"[WCPulseLoader] 收到卸载Hooks通知");
    [self uninstallAllHooks];
}

#pragma mark - Hook实现示例

- (void)hookMessageMethods {
    // Hook WeChat message-related methods - MessageRevokeMgr onRevokeMsg:
    NSLog(@"[WCPulseLoader] Hook消息相关方法");
    
    @try {
        Class MessageRevokeMgrClass = NSClassFromString(@"MessageRevokeMgr");
        if (MessageRevokeMgrClass) {
            SEL originalSelector = @selector(onRevokeMsg:);
            SEL swizzledSelector = @selector(wcpulse_onRevokeMsg:);
            
            Method originalMethod = class_getInstanceMethod(MessageRevokeMgrClass, originalSelector);
            Method loaderSwizzledMethod = class_getInstanceMethod([WCPulseLoader class], swizzledSelector);
            
            if (originalMethod && loaderSwizzledMethod) {
                // 先将 swizzled 方法添加到目标类（使用 swizzledSelector 名称）
                BOOL added = class_addMethod(MessageRevokeMgrClass,
                                             swizzledSelector,
                                             method_getImplementation(loaderSwizzledMethod),
                                             method_getTypeEncoding(loaderSwizzledMethod));
                
                // 获取添加到目标类后的 swizzled 方法引用
                Method targetSwizzledMethod = class_getInstanceMethod(MessageRevokeMgrClass, swizzledSelector);
                
                if (targetSwizzledMethod) {
                    // 在目标类内部交换 originalSelector 和 swizzledSelector 的实现
                    method_exchangeImplementations(originalMethod, targetSwizzledMethod);
                    NSLog(@"[WCPulseLoader] 成功Hook MessageRevokeMgr onRevokeMsg: (added=%@)", added ? @"YES" : @"NO");
                }
            }
        }
    } @catch (NSException *exception) {
        NSLog(@"[WCPulseLoader] Hook消息方法失败: %@", exception.reason);
    }
}

- (void)hookVideoMethods {
    // Hook WeChat video playback-related methods - video speed control etc.
    NSLog(@"[WCPulseLoader] Hook视频相关方法");
    
    @try {
        // Hook video player gesture recognition
        Class WCPlayerViewClass = NSClassFromString(@"WCPlayerView");
        if (WCPlayerViewClass) {
            // Hook video player's viewDidLoad method to add gesture recognition
            SEL originalSelector = @selector(viewDidLoad);
            SEL swizzledSelector = @selector(wcpulse_videoViewDidLoad);
            
            Method originalMethod = class_getInstanceMethod(WCPlayerViewClass, originalSelector);
            Method loaderSwizzledMethod = class_getInstanceMethod([WCPulseLoader class], swizzledSelector);
            
            if (originalMethod && loaderSwizzledMethod) {
                BOOL added = class_addMethod(WCPlayerViewClass,
                                             swizzledSelector,
                                             method_getImplementation(loaderSwizzledMethod),
                                             method_getTypeEncoding(loaderSwizzledMethod));
                
                Method targetSwizzledMethod = class_getInstanceMethod(WCPlayerViewClass, swizzledSelector);
                
                if (targetSwizzledMethod) {
                    method_exchangeImplementations(originalMethod, targetSwizzledMethod);
                    NSLog(@"[WCPulseLoader] 成功Hook WCPlayerView viewDidLoad (added=%@)", added ? @"YES" : @"NO");
                }
            }
            NSLog(@"[WCPulseLoader] 找到WCPlayerView类，已Hook视频手势");
        }
        
        // Hook UIViewController的viewDidAppear方法来测试SpeedFloatView显示
        Class UIViewControllerClass = [UIViewController class];
        if (UIViewControllerClass) {
            SEL originalSelector = @selector(viewDidAppear:);
            SEL swizzledSelector = @selector(wcpulse_viewDidAppear:);
            
            Method originalMethod = class_getInstanceMethod(UIViewControllerClass, originalSelector);
            Method loaderSwizzledMethod = class_getInstanceMethod([WCPulseLoader class], swizzledSelector);
            
            if (originalMethod && loaderSwizzledMethod) {
                BOOL added = class_addMethod(UIViewControllerClass,
                                             swizzledSelector,
                                             method_getImplementation(loaderSwizzledMethod),
                                             method_getTypeEncoding(loaderSwizzledMethod));
                
                Method targetSwizzledMethod = class_getInstanceMethod(UIViewControllerClass, swizzledSelector);
                
                if (targetSwizzledMethod) {
                    method_exchangeImplementations(originalMethod, targetSwizzledMethod);
                    NSLog(@"[WCPulseLoader] 成功Hook UIViewController viewDidAppear (added=%@)", added ? @"YES" : @"NO");
                }
            }
        }
        
        NSLog(@"[WCPulseLoader] 视频相关Hook已完成");
    } @catch (NSException *exception) {
        NSLog(@"[WCPulseLoader] Hook视频方法失败: %@", exception.reason);
    }
}

- (void)hookSessionMethods {
    // Hook微信的会话列表相关方法 - 会话分组、徽章显示等
    NSLog(@"[WCPulseLoader] Hook会话相关方法");
    
    @try {
        // Hook主会话视图控制器
        Class MainSessionViewControllerClass = NSClassFromString(@"MainSessionViewController");
        if (MainSessionViewControllerClass) {
            NSLog(@"[WCPulseLoader] 找到MainSessionViewController类");
        }
        
        // Hook会话单元格
        Class SessionCellViewClass = NSClassFromString(@"SessionCellView");
        if (SessionCellViewClass) {
            NSLog(@"[WCPulseLoader] 找到SessionCellView类");
        }
        
        // Hook会话管理器
        Class MMNewSessionMgrClass = NSClassFromString(@"MMNewSessionMgr");
        if (MMNewSessionMgrClass) {
            NSLog(@"[WCPulseLoader] 找到MMNewSessionMgr类");
        }
        
        NSLog(@"[WCPulseLoader] 会话相关Hook框架已准备就绪");
    } @catch (NSException *exception) {
        NSLog(@"[WCPulseLoader] Hook会话方法失败: %@", exception.reason);
    }
}

// Swizzled方法实现
- (void)wcpulse_onRevokeMsg:(id)message {
    // 检查是否启用消息防撤回
    BOOL enableNoRevoke = [WCPulseConfig enableMessageNoRevoke];
    
    if (enableNoRevoke) {
        NSLog(@"[WCPulseLoader] 拦截消息撤回: %@", message);
        
        // 显示提示（如果需要）
        if (![WCPulseConfig messageNoRevokeNoTip]) {
            [WCPulseHelper showModernToast:@"已拦截一条撤回消息"];
        }
        
        // 不调用原始方法，直接返回，阻止撤回
        return;
    }
    
    // 如果未启用防撤回，调用原始方法
    [self wcpulse_onRevokeMsg:message];
}

// Hook视频播放器的viewDidLoad方法
- (void)wcpulse_videoViewDidLoad {
    // 调用原始方法
    [self wcpulse_videoViewDidLoad];
    
    NSLog(@"[WCPulseLoader] 视频播放器加载完成，添加手势识别");
    
    // 检查是否启用视频速度手势
    if ([WCPulseConfig enableVideoSpeedGesture]) {
        // 添加双击手势来显示SpeedFloatView
        UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleVideoDoubleTap:)];
        doubleTap.numberOfTapsRequired = 2;
        [(UIView *)self addGestureRecognizer:doubleTap];
        
        NSLog(@"[WCPulseLoader] 已为视频播放器添加双击手势");
    }
}

// Hook UIViewController的viewDidAppear方法来测试SpeedFloatView
- (void)wcpulse_viewDidAppear:(BOOL)animated {
    // 调用原始方法
    [self wcpulse_viewDidAppear:animated];
    
    // 检查是否是微信的主界面或聊天界面
    NSString *className = NSStringFromClass([self class]);
    if ([className containsString:@"MainFrame"] || [className containsString:@"Chat"]) {
        NSLog(@"[WCPulseLoader] 检测到微信主要界面: %@", className);
        
        // 延迟3秒显示SpeedFloatView进行测试
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[WCPulse sharedInstance] showSpeedIndicator:@"测试" position:CGPointMake(100, 100)];
            NSLog(@"[WCPulseLoader] 已显示测试SpeedFloatView");
            
            // 5秒后隐藏
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[WCPulse sharedInstance] hideSpeedIndicator];
                NSLog(@"[WCPulseLoader] 已隐藏测试SpeedFloatView");
            });
        });
    }
}

// 处理视频双击手势
- (void)handleVideoDoubleTap:(UITapGestureRecognizer *)gesture {
    NSLog(@"[WCPulseLoader] 检测到视频双击手势");
    
    CGPoint location = [gesture locationInView:gesture.view];
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    
    // 根据点击位置确定速度
    NSString *speed = location.x < screenWidth / 2 ? @"0.5x" : @"2.0x";
    
    // 显示速度指示器
    [[WCPulse sharedInstance] showSpeedIndicator:speed position:location];
    
    // 2秒后隐藏
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[WCPulse sharedInstance] hideSpeedIndicator];
    });
}

#pragma mark - 兼容性检查

- (BOOL)checkWeChatCompatibility {
    NSString *version = [WCPulseHelper getWechatVersion];
    NSLog(@"[WCPulseLoader] 当前微信版本: %@", version);
    
    // 检查微信版本是否兼容
    if (!version || [version isEqualToString:@"未知版本"]) {
        NSLog(@"[WCPulseLoader] 无法获取微信版本");
        return NO;
    }
    
    // 使用正则表达式解析版本号
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"(\\d+)\\.(\\d+)\\.(\\d+)" options:0 error:nil];
    NSTextCheckingResult *match = [regex firstMatchInString:version options:0 range:NSMakeRange(0, version.length)];
    
    if (!match) {
        NSLog(@"[WCPulseLoader] 版本号格式不正确: %@", version);
        return NO;
    }
    
    // 提取主版本号
    NSInteger majorVersion = [[version substringWithRange:[match rangeAtIndex:1]] integerValue];
    
    // 检查版本兼容性：支持 8.0.0 及以上版本
    if (majorVersion < 8) {
        NSLog(@"[WCPulseLoader] 微信版本过低（需要8.0.0及以上），当前版本: %@", version);
        return NO;
    }
    
    NSLog(@"[WCPulseLoader] 微信版本兼容检查通过: %@", version);
    return YES;
}

#pragma mark - 应用生命周期

- (void)applicationDidFinishLaunching:(NSNotification *)notification {
    // 延迟加载插件，确保微信完全启动
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self loadPlugin];
        [[WCPulse sharedInstance] applicationDidFinishLaunching];
    });
}

- (void)applicationWillTerminate:(NSNotification *)notification {
    [self unloadPlugin];
}

@end

#pragma mark - 插件入口点

// 动态库构造函数，插件加载时自动调用
__attribute__((constructor))
static void WCPulsePluginEntry() {
    NSLog(@"[WCPulseLoader] WCPulse插件入口点被调用");
    
    // 确保在主线程中初始化
    dispatch_async(dispatch_get_main_queue(), ^{
        [[WCPulseLoader sharedLoader] loadPlugin];
    });
}

// 动态库析构函数，插件卸载时自动调用
__attribute__((destructor))
static void WCPulsePluginExit() {
    NSLog(@"[WCPulseLoader] WCPulse插件退出点被调用");
    [[WCPulseLoader sharedLoader] unloadPlugin];
}