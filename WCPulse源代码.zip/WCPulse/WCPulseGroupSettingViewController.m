#import "WCPulseGroupSettingViewController.h"
#import "WCPulseConfig.h"
#import "WCPulseHelper.h"
#import <objc/runtime.h>

@interface WCPulseGroupSettingViewController ()
@property (nonatomic, strong) NSMutableArray *dataSource;
@property (nonatomic, strong) NSMutableArray *sections;
@property (nonatomic, assign) BOOL isDarkMode;
@end

@implementation WCPulseGroupSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"WCPulse - 分组设置";
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];
    
    // 设置导航栏项目
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"关闭" style:UIBarButtonItemStylePlain target:self action:@selector(closeButtonTapped)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:UIBarButtonItemStyleDone target:self action:@selector(saveButtonTapped)];
    
    [self setupWechatColors];
    [self loadGroups];
    [self setupTableView];
}

- (void)setupWechatColors {
    self.isDarkMode = [UITraitCollection currentTraitCollection].userInterfaceStyle == UIUserInterfaceStyleDark;
    
    if (self.isDarkMode) {
        self.cellBackgroundColor = [UIColor colorWithRed:0.11 green:0.11 blue:0.12 alpha:1.0];
    } else {
        self.cellBackgroundColor = [UIColor whiteColor];
    }
}

- (UIColor *)cellBackgroundColor {
    return _cellBackgroundColor;
}

- (void)loadGroups {
    self.groupList = [[WCPulseConfig groupFilterList] mutableCopy] ?: [NSMutableArray array];
}

- (void)setupSettingsSwitches {
    // 设置开关的实现
}

- (void)setupTableView {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleInsetGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor systemGroupedBackgroundColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.allowsSelectionDuringEditing = YES;
    
    // 注册单元格类
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"DefaultCell"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"SwitchCell"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"ActionCell"];
    
    [self.view addSubview:self.tableView];
    
    // 自动布局
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.tableView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];
}

- (void)showGroupSelector {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"选择群组操作" 
                                                                   message:nil 
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *addAction = [UIAlertAction actionWithTitle:@"添加新群组" 
                                                        style:UIAlertActionStyleDefault 
                                                      handler:^(UIAlertAction * _Nonnull action) {
        [self showAddGroupDialog];
    }];
    [alert addAction:addAction];
    
    UIAlertAction *editAction = [UIAlertAction actionWithTitle:@"编辑群组" 
                                                         style:UIAlertActionStyleDefault 
                                                       handler:^(UIAlertAction * _Nonnull action) {
        [self toggleEditMode];
    }];
    [alert addAction:editAction];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" 
                                                           style:UIAlertActionStyleCancel 
                                                         handler:nil];
    [alert addAction:cancelAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)resetDefaultSettings {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"重置设置" 
                                                                   message:@"确定要重置所有设置到默认值吗？" 
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"确定" 
                                                            style:UIAlertActionStyleDestructive 
                                                          handler:^(UIAlertAction * _Nonnull action) {
        // 重置群组过滤列表为空
        [WCPulseConfig setGroupFilterList:@[]];
        [self loadGroups];
        [self.tableView reloadData];
        [WCPulseHelper showModernToast:@"设置已重置"];
    }];
    [alert addAction:confirmAction];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" 
                                                           style:UIAlertActionStyleCancel 
                                                         handler:nil];
    [alert addAction:cancelAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)showTagSelector {
    // 标签选择器的实现
}

- (void)saveGroups {
    [WCPulseConfig setGroupFilterList:self.groupList];
}

// 开关事件处理方法
- (void)enableGroupFilterChanged:(UISwitch *)sender {
    [WCPulseConfig setEnableGroupFilter:sender.isOn];
}

- (void)hideGroupIndicatorChanged:(UISwitch *)sender {
    [WCPulseConfig setHideGroupIndicator:sender.isOn];
}

- (void)hideGroupBadgeChanged:(UISwitch *)sender {
    [WCPulseConfig setHideGroupBadge:sender.isOn];
}

- (void)enableTopFilterChanged:(UISwitch *)sender {
    [WCPulseConfig setEnableTopFilter:sender.isOn];
}

- (void)enableGlobalSwitchGroupGestureChanged:(UISwitch *)sender {
    [WCPulseConfig setEnableGlobalSwitchGroupGesture:sender.isOn];
}

- (void)disableGroupTransitionAnimationChanged:(UISwitch *)sender {
    [WCPulseConfig setEnableGroupTransitionAnimation:!sender.isOn];
}

- (void)hideAllGroupBadgeChanged:(UISwitch *)sender {
    [WCPulseConfig setHideAllGroupBadge:sender.isOn];
}

- (void)hideGroupBackgroundColorChanged:(UISwitch *)sender {
    [WCPulseConfig setHideGroupBackgroundColor:sender.isOn];
}

- (void)filterDuplicateContactsChanged:(UISwitch *)sender {
    [WCPulseConfig setFilterDuplicateContacts:sender.isOn];
}

// 表格视图数据源
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4; // 群组、过滤设置、UI设置、操作
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0: // 群组
            return self.groupList.count + 1; // +1 用于添加群组按钮
        case 1: // 过滤设置
            return 3;
        case 2: // UI设置
            return 6;
        case 3: // 操作
            return 4;
        default:
            return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return @"群组管理";
        case 1:
            return @"过滤设置";
        case 2:
            return @"界面设置";
        case 3:
            return @"操作";
        default:
            return nil;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return @"管理您的会话群组，可以添加、编辑或删除群组。";
        case 1:
            return @"配置消息过滤和显示规则。";
        case 2:
            return @"自定义界面显示效果。";
        default:
            return nil;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell;
    
    switch (indexPath.section) {
        case 0: { // 群组
            if (indexPath.row < self.groupList.count) {
                cell = [tableView dequeueReusableCellWithIdentifier:@"DefaultCell" forIndexPath:indexPath];
                NSDictionary *group = self.groupList[indexPath.row];
                cell.textLabel.text = group[@"name"];
                cell.detailTextLabel.text = [group[@"enabled"] boolValue] ? @"启用" : @"禁用";
                cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                
                // 颜色指示器
                UIView *colorView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
                colorView.backgroundColor = [WCPulseConfig colorFromHexString:group[@"color"]];
                colorView.layer.cornerRadius = 10;
                cell.imageView.image = [self imageFromView:colorView];
            } else {
                cell = [tableView dequeueReusableCellWithIdentifier:@"ActionCell" forIndexPath:indexPath];
                cell.textLabel.text = @"添加群组";
                cell.textLabel.textColor = [UIColor systemBlueColor];
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
            break;
        }
        case 1: { // 过滤设置
            cell = [tableView dequeueReusableCellWithIdentifier:@"SwitchCell" forIndexPath:indexPath];
            UISwitch *switchControl = [[UISwitch alloc] init];
            cell.accessoryView = switchControl;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            switch (indexPath.row) {
                case 0:
                    cell.textLabel.text = @"启用群组过滤";
                    switchControl.on = [WCPulseConfig enableGroupFilter];
                    [switchControl addTarget:self action:@selector(enableGroupFilterChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
                case 1:
                    cell.textLabel.text = @"启用置顶过滤";
                    switchControl.on = [WCPulseConfig enableTopFilter];
                    [switchControl addTarget:self action:@selector(enableTopFilterChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
                case 2:
                    cell.textLabel.text = @"全局切换群组手势";
                    switchControl.on = [WCPulseConfig enableGlobalSwitchGroupGesture];
                    [switchControl addTarget:self action:@selector(enableGlobalSwitchGroupGestureChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
            }
            break;
        }
        case 2: { // UI设置
            cell = [tableView dequeueReusableCellWithIdentifier:@"SwitchCell" forIndexPath:indexPath];
            UISwitch *switchControl = [[UISwitch alloc] init];
            cell.accessoryView = switchControl;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            switch (indexPath.row) {
                case 0:
                    cell.textLabel.text = @"隐藏群组指示器";
                    switchControl.on = [WCPulseConfig hideGroupIndicator];
                    [switchControl addTarget:self action:@selector(hideGroupIndicatorChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
                case 1:
                    cell.textLabel.text = @"隐藏群组角标";
                    switchControl.on = [WCPulseConfig hideGroupBadge];
                    [switchControl addTarget:self action:@selector(hideGroupBadgeChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
                case 2:
                    cell.textLabel.text = @"隐藏所有群组角标";
                    switchControl.on = [WCPulseConfig hideAllGroupBadge];
                    [switchControl addTarget:self action:@selector(hideAllGroupBadgeChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
                case 3:
                    cell.textLabel.text = @"隐藏群组背景色";
                    switchControl.on = [WCPulseConfig hideGroupBackgroundColor];
                    [switchControl addTarget:self action:@selector(hideGroupBackgroundColorChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
                case 4:
                    cell.textLabel.text = @"禁用群组转场动画";
                    switchControl.on = ![WCPulseConfig enableGroupTransitionAnimation];
                    [switchControl addTarget:self action:@selector(disableGroupTransitionAnimationChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
                case 5:
                    cell.textLabel.text = @"过滤重复联系人";
                    switchControl.on = [WCPulseConfig filterDuplicateContacts];
                    [switchControl addTarget:self action:@selector(filterDuplicateContactsChanged:) forControlEvents:UIControlEventValueChanged];
                    break;
            }
            break;
        }
        case 3: { // 操作
            cell = [tableView dequeueReusableCellWithIdentifier:@"ActionCell" forIndexPath:indexPath];
            switch (indexPath.row) {
                case 0:
                    cell.textLabel.text = @"选择标签";
                    cell.textLabel.textColor = [UIColor systemBlueColor];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                    break;
                case 1:
                    cell.textLabel.text = @"修改版本";
                    cell.textLabel.textColor = [UIColor systemBlueColor];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                    break;
                case 2:
                    cell.textLabel.text = @"设置默认群组";
                    cell.textLabel.textColor = [UIColor systemBlueColor];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                    break;
                case 3:
                    cell.textLabel.text = @"重置设置";
                    cell.textLabel.textColor = [UIColor systemRedColor];
                    cell.accessoryType = UITableViewCellAccessoryNone;
                    break;
            }
            break;
        }
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.section) {
        case 0: // 群组
            if (indexPath.row < self.groupList.count) {
                [self editGroupAtIndex:indexPath.row];
            } else {
                [self showAddGroupDialog];
            }
            break;
        case 3: { // 操作
            switch (indexPath.row) {
                case 0:
                    [self showTagSelector];
                    break;
                case 1: {
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"修改版本"
                                                                                   message:@"输入你要修改的版本"
                                                                            preferredStyle:UIAlertControllerStyleAlert];
                    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
                        textField.placeholder = @"版本";
                        textField.text = [WCPulseConfig pluginVer];
                    }];
                    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        NSString *ver = alert.textFields.firstObject.text ?: @"";
                        [WCPulseConfig setPluginVer:ver];
                        [WCPulseHelper showModernToast:[NSString stringWithFormat:@"版本已设置为: %@", ver]];
                    }];
                    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
                    [alert addAction:ok];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                } break;
                case 2: {
                    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"设置默认群组" message:@"选择一个群组作为默认群组" preferredStyle:UIAlertControllerStyleActionSheet];
                    for (NSInteger i = 0; i < self.groupList.count; i++) {
                        NSDictionary *group = self.groupList[i];
                        UIAlertAction *action = [UIAlertAction actionWithTitle:group[@"name"] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                            [WCPulseConfig setDefaultGroupIndex:i];
                            [self.tableView reloadData];
                        }];
                        [sheet addAction:action];
                    }
                    UIAlertAction *unset = [UIAlertAction actionWithTitle:@"不设置" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
                        [WCPulseConfig setDefaultGroupIndex:-1];
                        [self.tableView reloadData];
                    }];
                    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
                    [sheet addAction:unset];
                    [sheet addAction:cancel];
                    [self presentViewController:sheet animated:YES completion:nil];
                } break;
                case 3:
                    [self resetDefaultSettings];
                    break;
            }
            break;
        }
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 44.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return section < 3 ? 44.0 : 1.0;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.section == 0 && indexPath.row < self.groupList.count;
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.section == 0 && indexPath.row < self.groupList.count;
}

- (NSIndexPath *)tableView:(UITableView *)tableView targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)sourceIndexPath toProposedIndexPath:(NSIndexPath *)proposedDestinationIndexPath {
    if (proposedDestinationIndexPath.section != 0 || proposedDestinationIndexPath.row >= self.groupList.count) {
        return sourceIndexPath;
    }
    return proposedDestinationIndexPath;
}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
    if (fromIndexPath.section == 0 && toIndexPath.section == 0) {
        id object = self.groupList[fromIndexPath.row];
        [self.groupList removeObjectAtIndex:fromIndexPath.row];
        [self.groupList insertObject:object atIndex:toIndexPath.row];
        [self saveGroups];
    }
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0 && indexPath.row < self.groupList.count) {
        return UITableViewCellEditingStyleDelete;
    }
    return UITableViewCellEditingStyleNone;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete && indexPath.section == 0) {
        [self.groupList removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self saveGroups];
    }
}

- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @[];
}

// 辅助方法
- (void)closeButtonTapped {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)saveButtonTapped {
    [self saveGroups];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)showAddGroupDialog {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"添加群组" 
                                                                   message:@"输入群组名称" 
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"群组名称";
    }];
    
    UIAlertAction *addAction = [UIAlertAction actionWithTitle:@"添加" 
                                                        style:UIAlertActionStyleDefault 
                                                      handler:^(UIAlertAction * _Nonnull action) {
        NSString *groupName = alert.textFields.firstObject.text;
        if (groupName.length > 0) {
            NSDictionary *newGroup = @{
                @"name": groupName,
                @"enabled": @YES,
                @"color": @"#007AFF",
                @"contacts": @[]
            };
            [self.groupList addObject:newGroup];
            [self.tableView reloadData];
            [self saveGroups];
        }
    }];
    [alert addAction:addAction];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" 
                                                           style:UIAlertActionStyleCancel 
                                                         handler:nil];
    [alert addAction:cancelAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)editGroupAtIndex:(NSInteger)index {
    if (index >= 0 && index < self.groupList.count) {
        NSDictionary *group = self.groupList[index];
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"编辑群组" 
                                                                       message:@"修改群组信息" 
                                                                preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = @"群组名称";
            textField.text = group[@"name"];
        }];
        
        UIAlertAction *saveAction = [UIAlertAction actionWithTitle:@"保存" 
                                                             style:UIAlertActionStyleDefault 
                                                           handler:^(UIAlertAction * _Nonnull action) {
            NSString *newName = alert.textFields.firstObject.text;
            if (newName.length > 0) {
                NSMutableDictionary *updatedGroup = [group mutableCopy];
                updatedGroup[@"name"] = newName;
                self.groupList[index] = updatedGroup;
                [self.tableView reloadData];
                [self saveGroups];
            }
        }];
        [alert addAction:saveAction];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" 
                                                               style:UIAlertActionStyleCancel 
                                                             handler:nil];
        [alert addAction:cancelAction];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (void)toggleEditMode {
    self.tableView.editing = !self.tableView.editing;
    self.navigationItem.rightBarButtonItem.title = self.tableView.editing ? @"完成" : @"编辑";
}

- (UIImage *)imageFromView:(UIView *)view {
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, [UIScreen mainScreen].scale);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end