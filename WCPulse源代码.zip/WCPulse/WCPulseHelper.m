#import "WCPulseHelper.h"
#import "SpeedFloatView.h"
#import <objc/runtime.h>
#import <CoreMotion/CoreMotion.h>
#import <AudioToolbox/AudioToolbox.h>

@interface WCPulseHelper ()
@property (nonatomic, strong) CMMotionManager *motionManager;
@property (nonatomic, strong) NSOperationQueue *motionQueue;
@end

@implementation WCPulseHelper

+ (instancetype)shared {
    static WCPulseHelper *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[WCPulseHelper alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _checkFriendsEnd = NO;
        _notFriends = [[NSMutableArray alloc] init];
        _invalidFriends = [[NSMutableArray alloc] init];
        _validFriends = [[NSMutableArray alloc] init];
        _groupURL = @"";
        _currentCheckResult = @"";
        _friendCheckSem = dispatch_semaphore_create(0);
        
        _motionManager = [[CMMotionManager alloc] init];
        _motionQueue = [[NSOperationQueue alloc] init];
    }
    return self;
}

#pragma mark - UI工具方法

+ (void)showModernToast:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *topVC = [self findTopVC];
        if (!topVC) return;
        
        UIView *toastView = [[UIView alloc] init];
        toastView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.8];
        toastView.layer.cornerRadius = 8.0;
        
        UILabel *messageLabel = [[UILabel alloc] init];
        messageLabel.text = message;
        messageLabel.textColor = [UIColor whiteColor];
        messageLabel.font = [UIFont systemFontOfSize:16];
        messageLabel.textAlignment = NSTextAlignmentCenter;
        messageLabel.numberOfLines = 0;
        
        [toastView addSubview:messageLabel];
        messageLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [NSLayoutConstraint activateConstraints:@[
            [messageLabel.centerXAnchor constraintEqualToAnchor:toastView.centerXAnchor],
            [messageLabel.centerYAnchor constraintEqualToAnchor:toastView.centerYAnchor],
            [messageLabel.leadingAnchor constraintEqualToAnchor:toastView.leadingAnchor constant:16],
            [messageLabel.trailingAnchor constraintEqualToAnchor:toastView.trailingAnchor constant:-16],
            [messageLabel.topAnchor constraintEqualToAnchor:toastView.topAnchor constant:12],
            [messageLabel.bottomAnchor constraintEqualToAnchor:toastView.bottomAnchor constant:-12]
        ]];
        
        [topVC.view addSubview:toastView];
        toastView.translatesAutoresizingMaskIntoConstraints = NO;
        [NSLayoutConstraint activateConstraints:@[
            [toastView.centerXAnchor constraintEqualToAnchor:topVC.view.centerXAnchor],
            [toastView.bottomAnchor constraintEqualToAnchor:topVC.view.safeAreaLayoutGuide.bottomAnchor constant:-100]
        ]];
        
        toastView.alpha = 0;
        [UIView animateWithDuration:0.3 animations:^{
            toastView.alpha = 1;
        } completion:^(BOOL finished) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [UIView animateWithDuration:0.3 animations:^{
                    toastView.alpha = 0;
                } completion:^(BOOL finished) {
                    [toastView removeFromSuperview];
                }];
            });
        }];
    });
}

+ (UIViewController *)findTopVC {
    UIViewController *topVC = nil;
    
    // iOS 13+ 兼容性处理
    if (@available(iOS 13.0, *)) {
        NSSet *connectedScenes = [UIApplication sharedApplication].connectedScenes;
        for (UIScene *scene in connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]]) {
                UIWindowScene *windowScene = (UIWindowScene *)scene;
                for (UIWindow *window in windowScene.windows) {
                    if (window.isKeyWindow) {
                        topVC = window.rootViewController;
                        break;
                    }
                }
                if (topVC) break;
            }
        }
    } else {
        // iOS 13以下版本使用keyWindow
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        topVC = [UIApplication sharedApplication].keyWindow.rootViewController;
#pragma clang diagnostic pop
    }
    
    while (topVC.presentedViewController) {
        topVC = topVC.presentedViewController;
    }
    
    if ([topVC isKindOfClass:[UINavigationController class]]) {
        topVC = [(UINavigationController *)topVC topViewController];
    } else if ([topVC isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabBarController = (UITabBarController *)topVC;
        topVC = tabBarController.selectedViewController;
        if ([topVC isKindOfClass:[UINavigationController class]]) {
            topVC = [(UINavigationController *)topVC topViewController];
        }
    }
    
    return topVC;
}

+ (UIView *)findTopVCView {
    return [[self findTopVC] view];
}

+ (UINavigationController *)navigationContrioller {
    UIViewController *topVC = [self findTopVC];
    return topVC.navigationController;
}

+ (UIBarButtonItem *)leftNavigationItem {
    UIViewController *topVC = [self findTopVC];
    return topVC.navigationItem.leftBarButtonItem;
}

+ (UIColor *)backgroundColor {
    return [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1.0];
}

+ (void)Log:(NSString *)message {
    NSLog(@"[WCPulse] %@", message);
}

+ (CGRect)viewFrame {
    return [UIScreen mainScreen].bounds;
}

+ (NSString *)hexStringFromColor:(UIColor *)color {
    CGFloat red, green, blue, alpha;
    [color getRed:&red green:&green blue:&blue alpha:&alpha];
    
    int r = (int)(red * 255);
    int g = (int)(green * 255);
    int b = (int)(blue * 255);
    
    return [NSString stringWithFormat:@"#%02X%02X%02X", r, g, b];
}

+ (void)vibrate {
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
}

#pragma mark - 表格管理

+ (UITableView *)tableManageWithViewFrame:(CGRect)frame {
    UITableView *tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStyleGrouped];
    tableView.backgroundColor = [self backgroundColor];
    tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    return tableView;
}

+ (NSString *)sectionManage {
    return @"WCPulse设置";
}

+ (UITableViewCell *)cellWithTitle:(NSString *)title {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.textLabel.text = title;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

+ (UITableViewCell *)cellWithTitle:(NSString *)title detail:(NSString *)detail {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    cell.textLabel.text = title;
    cell.detailTextLabel.text = detail;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

+ (UITableViewCell *)cellWithTitle:(NSString *)title switchAction:(void(^)(BOOL))action {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.textLabel.text = title;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    UISwitch *switchControl = [[UISwitch alloc] init];
    cell.accessoryView = switchControl;
    
    return cell;
}

#pragma mark - 弹窗管理

+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message btnTitle:(NSString *)btnTitle handler:(void(^)(void))handler {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:btnTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            if (handler) {
                handler();
            }
        }];
        [alert addAction:action];
        
        UIViewController *topVC = [self findTopVC];
        [topVC presentViewController:alert animated:YES completion:nil];
    });
}

+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message cancelTitle:(NSString *)cancelTitle confirmTitle:(NSString *)confirmTitle handler:(void(^)(BOOL))handler {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            if (handler) {
                handler(NO);
            }
        }];
        [alert addAction:cancelAction];
        
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:confirmTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            if (handler) {
                handler(YES);
            }
        }];
        [alert addAction:confirmAction];
        
        UIViewController *topVC = [self findTopVC];
        [topVC presentViewController:alert animated:YES completion:nil];
    });
}

#pragma mark - 消息发送

+ (void)sendMsg:(NSString *)message toContactUsrName:(NSString *)contactUsrName {
    NSLog(@"发送消息: %@ 到联系人: %@", message, contactUsrName);
}

+ (void)sendMsg:(NSString *)message toContactUsrName:(NSString *)contactUsrName uiMsgType:(NSInteger)msgType {
    NSLog(@"发送消息: %@ 到联系人: %@ 类型: %ld", message, contactUsrName, (long)msgType);
}

#pragma mark - 好友检测

+ (NSArray *)allFriends {
    return @[];
}

+ (void)checkFriends {
    NSLog(@"开始检测好友状态");
}

+ (NSArray *)commentUsers {
    return @[];
}

+ (void)commentWith:(NSString *)comment {
    NSLog(@"发表评论: %@", comment);
}

- (void)setCheckFriendsEndAndSignal {
    self.checkFriendsEnd = YES;
    dispatch_semaphore_signal(self.friendCheckSem);
}

#pragma mark - 系统工具

+ (BOOL)vapFileExit {
    return NO;
}

+ (NSString *)getWechatVersion {
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSString *version = [mainBundle objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
    return version ?: @"未知版本";
}



#pragma mark - Speed Float View Methods

- (void)showSpeedFloatView {
    // 显示速度浮窗
    SpeedFloatView *speedView = [SpeedFloatView sharedInstance];
    [speedView showWithSpeed:1.0f isLeftSide:YES];
}

- (void)hideSpeedFloatView {
    // 隐藏速度浮窗
    SpeedFloatView *speedView = [SpeedFloatView sharedInstance];
    [speedView hide];
}

#pragma mark - 公众号相关

+ (void)followMyOfficalAccount {
    NSLog(@"关注公众号");
}

+ (void)jumpToOfficialAccount {
    NSLog(@"跳转到公众号");
}

+ (BOOL)isOfficialAccountFollowed {
    return NO;
}

#pragma mark - 实例方法

- (void)action1:(id)sender {
    NSLog(@"执行动作1");
}

- (void)action2:(id)sender {
    NSLog(@"执行动作2");
}

@end