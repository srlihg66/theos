#import <UIKit/UIKit.h>

@interface WCPulseGroupSettingViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UIActionSheetDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *groupList;
@property (nonatomic, strong) NSMutableArray *settingSwitches;
@property (nonatomic, assign) BOOL isEditing;
@property (nonatomic, strong) UIColor *cellBackgroundColor;

- (void)viewDidLoad;
- (void)setupWechatColors;
- (UIColor *)cellBackgroundColor;
- (void)loadGroups;
- (void)setupSettingsSwitches;
- (void)setupTableView;
- (void)showGroupSelector;

- (void)resetDefaultSettings;
- (void)showTagSelector;
- (void)saveGroups;

// 开关事件处理方法
- (void)enableGroupFilterChanged:(UISwitch *)sender;
- (void)hideGroupIndicatorChanged:(UISwitch *)sender;
- (void)hideGroupBadgeChanged:(UISwitch *)sender;
- (void)enableTopFilterChanged:(UISwitch *)sender;
- (void)enableGlobalSwitchGroupGestureChanged:(UISwitch *)sender;
- (void)disableGroupTransitionAnimationChanged:(UISwitch *)sender;
- (void)hideAllGroupBadgeChanged:(UISwitch *)sender;
- (void)hideGroupBackgroundColorChanged:(UISwitch *)sender;
- (void)filterDuplicateContactsChanged:(UISwitch *)sender;

// 表格视图代理和数据源方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section;
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section;
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section;
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath;
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath;
- (NSIndexPath *)tableView:(UITableView *)tableView targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)sourceIndexPath toProposedIndexPath:(NSIndexPath *)proposedDestinationIndexPath;
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath;
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath;
- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath;

@end